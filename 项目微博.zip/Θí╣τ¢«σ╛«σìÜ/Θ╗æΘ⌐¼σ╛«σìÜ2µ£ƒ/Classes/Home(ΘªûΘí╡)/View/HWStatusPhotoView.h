//
//  HWStatusPhotoView.h
//  黑马微博2期
//
//  Created by apple on 14-10-18.
//  Copyright (c) 2014年 heima. All rights reserved.
//  一张配图

#import <UIKit/UIKit.h>
@class HWPhoto;

@interface HWStatusPhotoView : UIImageView
@property (nonatomic, strong) HWPhoto *photo;
@end
