//
//  HWConst.m
//  黑马微博2期
//
//  Created by apple on 14-10-25.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <Foundation/Foundation.h>

// 账号信息
NSString * const HWAppKey = @"277040274";
NSString * const HWRedirectURI = @"http://";
NSString * const HWAppSecret = @"fdf0bc144842248f9fa729eb0aa97320";

// 通知
// 表情选中的通知
NSString * const HWEmotionDidSelectNotification = @"HWEmotionDidSelectNotification";
NSString * const HWSelectEmotionKey = @"HWSelectEmotionKey";

// 删除文字的通知
NSString * const HWEmotionDidDeleteNotification = @"HWEmotionDidDeleteNotification";
